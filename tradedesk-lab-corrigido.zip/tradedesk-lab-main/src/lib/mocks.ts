import type { Acao } from "@/types/acao";
import type { Ordem } from "@/types/ordem";

// array de acoes exportado direto, mais facil de acessar em qualquer lugar
export const ACOES_MOCK: Acao[] = [
  { ticker: "PETR4", nome: "Petrobras PN N2", preco: 38.42, variacao: -1.23, volume: 42831900 },
  { ticker: "VALE3", nome: "Vale ON NM", preco: 61.80, variacao: 0.87, volume: 31200000 },
  { ticker: "ITUB4", nome: "Itaú Unibanco PN", preco: 34.55, variacao: 0.32, volume: 28900000 },
  { ticker: "MGLU3", nome: "Magazine Luiza ON NM", preco: 7.21, variacao: -3.40, volume: 89500000 },
  { ticker: "BBDC4", nome: "Bradesco PN N1", preco: 12.88, variacao: 1.15, volume: 19800000 },
];

export const ORDENS_MOCK: Ordem[] = [];

// Normaliza o retorno raw da brapi.dev (symbol, shortName, regularMarketPrice,
// regularMarketChangePercent, regularMarketVolume, logourl) ou um objeto já no
// formato mock para o formato canônico `Acao`. Usado pelas rotas de API para
// que o resto da aplicação nunca precise lidar com os dois formatos (Bug B13).
export function normalizeAcao(raw: any): Acao {
  return {
    ticker: raw.symbol ?? raw.ticker,
    nome: raw.shortName ?? raw.nome,
    preco: raw.regularMarketPrice ?? raw.preco ?? 0,
    variacao: raw.regularMarketChangePercent ?? raw.variacao ?? 0,
    volume: raw.regularMarketVolume ?? raw.volume ?? 0,
    logo: raw.logourl ?? raw.logo,
  };
}
