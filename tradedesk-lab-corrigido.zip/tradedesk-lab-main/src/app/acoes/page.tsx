import Link from "next/link";
import type { Acao } from "@/types/acao";

export default async function AcoesPage() {
  const res = await fetch("http://localhost:3000/api/acoes", { cache: "no-store" });
  const acoes: Acao[] = await res.json();

  return (
    <div style={{ maxWidth: "1100px", margin: "0 auto", padding: "2rem" }}>
      <h1 style={{ fontSize: "1.5rem", fontWeight: 700, marginBottom: "2rem" }}>Ações disponíveis</h1>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ borderBottom: "1px solid #2a2a2a", color: "#888", fontSize: "0.75rem" }}>
            <th style={{ textAlign: "left", padding: "0.75rem 1rem" }}>TICKER</th>
            <th style={{ textAlign: "left", padding: "0.75rem 1rem" }}>NOME</th>
            <th style={{ textAlign: "right", padding: "0.75rem 1rem" }}>PREÇO</th>
            <th style={{ textAlign: "right", padding: "0.75rem 1rem" }}>VARIAÇÃO</th>
            <th style={{ textAlign: "right", padding: "0.75rem 1rem" }}>VOLUME</th>
            <th style={{ padding: "0.75rem 1rem" }}></th>
          </tr>
        </thead>
        <tbody>
          {acoes.map((acao) => (
            <tr key={acao.ticker} style={{ borderBottom: "1px solid #1a1a1a" }}>
              <td style={{ padding: "1rem", fontWeight: 700, color: "#f59e0b" }}>{acao.ticker}</td>
              <td style={{ padding: "1rem", color: "#888", fontSize: "0.85rem" }}>{acao.nome}</td>
              <td style={{ padding: "1rem", textAlign: "right" }}>R$ {acao.preco.toFixed(2)}</td>
              <td style={{ padding: "1rem", textAlign: "right" }} className={acao.variacao >= 0 ? "positivo" : "negativo"}>
                {acao.variacao >= 0 ? "▲" : "▼"} {Math.abs(acao.variacao).toFixed(2)}%
              </td>
              <td style={{ padding: "1rem", textAlign: "right", color: "#888", fontSize: "0.8rem" }}>{acao.volume.toLocaleString("pt-BR")}</td>
              <td style={{ padding: "1rem" }}>
                <Link href={`/acoes/${acao.ticker}`} style={{ background: "#1a2a1a", border: "1px solid #22c55e", color: "#22c55e", padding: "0.35rem 0.75rem", borderRadius: 4, textDecoration: "none", fontSize: "0.8rem" }}>
                  Ver →
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
