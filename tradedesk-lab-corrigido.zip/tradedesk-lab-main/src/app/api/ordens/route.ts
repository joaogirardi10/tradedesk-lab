import { NextResponse } from "next/server";
import { ORDENS_MOCK } from "@/lib/mocks";
import type { Ordem } from "@/types/ordem";

const LOTE_MINIMO = 100;

export async function GET() {
  return NextResponse.json(ORDENS_MOCK);
}

export async function POST(req: Request) {
  const body = await req.json();

  // Bug B10 (corrigido): a B3 opera em lotes padrão de 100 ações — não dá
  // pra comprar 3 ou 250 ações avulsas, só múltiplos de 100 (o mercado
  // fracionário é um sistema à parte). Quantidades zero, negativas ou que
  // não sejam múltiplas de 100 são rejeitadas.
  const quantidade = Number(body.quantidade);
  const isMultiploDoLote = quantidade > 0 && quantidade % LOTE_MINIMO === 0;
  if (!Number.isFinite(quantidade) || !isMultiploDoLote) {
    return NextResponse.json(
      { error: `Quantidade deve ser um múltiplo de ${LOTE_MINIMO} ações (lote padrão da B3)` },
      { status: 400 }
    );
  }

  const ordem: Ordem = {
    id: crypto.randomUUID(),
    ticker: body.ticker,
    quantidade,
    preco: body.preco,
    total: body.total,
    tipo: "compra",
    timestamp: new Date().toISOString(),
  };

  // Bug B12 (corrigido): estava dando push na array errada (ACOES_MOCK em
  // vez de ORDENS_MOCK), então após algumas ordens /api/acoes passava a
  // retornar ações misturadas com ordens de compra.
  ORDENS_MOCK.push(ordem);

  return NextResponse.json(ordem, { status: 201 });
}
