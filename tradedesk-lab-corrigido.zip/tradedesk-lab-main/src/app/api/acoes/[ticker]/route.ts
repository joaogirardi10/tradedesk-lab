import { NextResponse } from "next/server";
import { ACOES_MOCK, normalizeAcao } from "@/lib/mocks";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ ticker: string }> }
) {
  const { ticker } = await params;

  try {
    const res = await fetch(`https://brapi.dev/api/quote/${ticker}?fundamental=false`, {
      next: { revalidate: 30 },
    });
    if (!res.ok) throw new Error("brapi offline");
    const data = await res.json();

    // Quando o ticker não existe na brapi, results vem como array vazio.
    // Nesse caso o recurso realmente não existe, então respondemos 404 (fix Bug B9).
    if (!data.results || data.results.length === 0) {
      return NextResponse.json({ error: `Ação ${ticker} não encontrada` }, { status: 404 });
    }
    return NextResponse.json(normalizeAcao(data.results[0]));
  } catch {
    const acao = ACOES_MOCK.find(a => a.ticker === ticker.toUpperCase());
    if (!acao) {
      return NextResponse.json({ error: `Ação ${ticker} não encontrada` }, { status: 404 });
    }
    return NextResponse.json(normalizeAcao(acao));
  }
}
