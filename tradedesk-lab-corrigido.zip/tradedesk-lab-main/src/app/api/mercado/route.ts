import { NextResponse } from "next/server";

export async function GET() {
  // Bug B11 (corrigido): new Date().getHours() usa o timezone do servidor
  // (que pode ser UTC, ou qualquer outro, dependendo de onde a app está
  // hospedada), não o horário de Brasília. Usamos Intl.DateTimeFormat com
  // timeZone: "America/Sao_Paulo" para obter a hora correta independente
  // de onde o processo Node está rodando.
  const hora = Number(
    new Intl.DateTimeFormat("pt-BR", {
      timeZone: "America/Sao_Paulo",
      hour: "numeric",
      hour12: false,
    }).format(new Date())
  );

  // Horário de funcionamento da B3: 10h–17h30 (horário de Brasília)
  const abertura = 10;
  const fechamento = 17;

  const isAberto = hora >= abertura && hora < fechamento;

  return NextResponse.json({
    status: isAberto ? "aberto" : "fechado",
    hora: hora,
    mensagem: isAberto
      ? `Mercado aberto — ${hora}h`
      : `Mercado fechado — abre às ${abertura}h`,
    abertura,
    fechamento,
  });
}
