// Formato canônico usado em toda a aplicação. As rotas de API (src/app/api/acoes/*)
// são responsáveis por normalizar tanto o retorno raw da brapi.dev (symbol, shortName,
// regularMarketPrice, regularMarketChangePercent, regularMarketVolume, logourl) quanto
// os dados mock para este formato, então componentes e páginas podem sempre confiar
// em acao.preco, acao.nome etc. sem precisar de fallback com "??" (fix Bug B13).
export interface Acao {
  ticker: string;
  nome: string;
  preco: number;
  variacao: number;
  volume: number;
  logo?: string;
}
